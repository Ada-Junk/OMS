
from functools import wraps
from flask import g, redirect, url_for, session


def login_required(func):
    # 保留func的信息
    @wraps(func)
    def inner(*args, **kwargs):
        user_id = session.get('user_id')
        if user_id:
            func(*args, **kwargs)
        else:
            return redirect(url_for("user.login"))
    return inner

# @login_required
# def public(user_id):
#     pass
# login_required(public)(user_id)