import csv
import io
from io import BytesIO

import matplotlib
import pandas as pd
import pytz
from sqlalchemy import create_engine, text, func
from flask import Blueprint, render_template, session, redirect, url_for, g, send_file, make_response
from decorator import login_required
from .forms import OrderForm
from models import OrderModel, GoodsModel, GuestModel, UserModel
from exts import db
from datetime import datetime, timedelta
from io import StringIO
import csv
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter
import openpyxl

bp = Blueprint("main", __name__, url_prefix="/")


@bp.route("/")
def index():
    if g.user:
        today_total_sale = 0
        today_total_sales = 0
        today_total_profit = 0
        month_total_sale = 0
        month_total_sales = 0
        month_total_profit = 0
        now = datetime.now()
        today = datetime.now().date()
        # 今天开始
        today_start = datetime(now.year, now.month, now.day)
        # 今天结束
        today_end = today_start + timedelta(days=1) - timedelta(seconds=1)
        # 这个月的开始时间
        first_day_of_month = datetime(now.year, now.month, 1)
        # 这个月的结束时间
        last_day_of_month = datetime(now.year, now.month + 1, 1) - timedelta(days=1)
        today_records = OrderModel.query.filter(OrderModel.order_time.between(today_start, today_end)).filter_by(
            merchant_id=g.user.id).all()
        month_records = OrderModel.query.filter(
            OrderModel.order_time.between(first_day_of_month, last_day_of_month)).filter_by(
            merchant_id=g.user.id).all()
        for this in today_records:
            goods_cost = GoodsModel.query.filter_by(merchant_id=g.user.id, goods_name=this.goods_name).first()
            today_total_sale += this.quantity
            today_total_sales += this.total
            today_total_profit = today_total_profit + this.total - goods_cost.cost_price * this.quantity
            print(goods_cost.cost_price, this.price, this.quantity, this.total, today_total_profit)
        for this in month_records:
            goods_cost = GoodsModel.query.filter_by(merchant_id=g.user.id, goods_name=this.goods_name).first()
            month_total_sale += this.quantity
            month_total_sales += this.total
            month_total_profit = month_total_profit + this.total - goods_cost.cost_price * this.quantity
            print(goods_cost.cost_price, this.price, this.quantity, this.total, month_total_profit)
        return render_template("main.html", quantity=today_total_sale, total=today_total_sales,
                               profit=today_total_profit, month_quantity=month_total_sale,
                               month_total=month_total_sales, month_profit=month_total_profit)
    return redirect(url_for("user.login"))


@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for("user.login"))


@bp.route('/cancel_account')
def cancel_account():
    merchant_id = g.user.id
    user = UserModel.query.filter_by(id=merchant_id).first()
    orders = OrderModel.query.filter_by(merchant_id=merchant_id).all()
    goods = GoodsModel.query.filter_by(merchant_id=merchant_id).all()
    guests = GuestModel.query.filter_by(merchant_id=merchant_id).all()
    if user:
        if orders:
            for order in orders:
                print("删除order")
                db.session.delete(order)
        if goods:
            for good in goods:
                print("删除good")
                db.session.delete(good)
        if guests:
            for guest in guests:
                print("删除guest")
                db.session.delete(guest)
        db.session.delete(user)
        db.session.commit()
    session.clear()
    return render_template("login.html")


@bp.route('/usage')
def usage():
    return render_template("usage.html")


@bp.route('/order')
def order():
    merchant_id = g.user.id
    data = OrderModel.query.filter_by(merchant_id=merchant_id)
    return render_template("order.html", data=data)


@bp.route('/situation')
def situation():
    today_total_sale = 0
    today_total_sales = 0
    today_total_profit = 0
    month_total_sale = 0
    month_total_sales = 0
    month_total_profit = 0
    now = datetime.now()
    # 今天开始
    today_start = datetime(now.year, now.month, now.day)
    # 今天结束
    today_end = today_start + timedelta(days=1) - timedelta(seconds=1)
    # 这个月的开始时间
    first_day_of_month = datetime(now.year, now.month, 1)
    # 这个月的结束时间
    last_day_of_month = datetime(now.year, now.month + 1, 1) - timedelta(days=1)
    today_records = OrderModel.query.filter(OrderModel.order_time.between(today_start, today_end)).filter_by(
        merchant_id=g.user.id).all()
    month_records = OrderModel.query.filter(
        OrderModel.order_time.between(first_day_of_month, last_day_of_month)).filter_by(
        merchant_id=g.user.id).all()
    for this in today_records:
        goods_cost = GoodsModel.query.filter_by(merchant_id=g.user.id, goods_name=this.goods_name).first()
        today_total_sale += this.quantity
        today_total_sales += this.total
        today_total_profit = today_total_profit + this.total - goods_cost.cost_price * this.quantity
        print(goods_cost.cost_price, this.price, this.quantity, this.total, today_total_profit)
    for this in month_records:
        goods_cost = GoodsModel.query.filter_by(merchant_id=g.user.id, goods_name=this.goods_name).first()
        month_total_sale += this.quantity
        month_total_sales += this.total
        month_total_profit = month_total_profit + this.total - goods_cost.cost_price * this.quantity
        print(goods_cost.cost_price, this.price, this.quantity, this.total, month_total_profit)
    return render_template("situation.html", quantity=today_total_sale, total=today_total_sales,
                           profit=today_total_profit, month_quantity=month_total_sale, month_total=month_total_sales,
                           month_profit=month_total_profit)


@bp.route('/goods')
def goods():
    merchant_id = g.user.id
    data = GoodsModel.query.filter_by(merchant_id=merchant_id)
    return render_template("goods.html", data=data)


@bp.route('/center')
def center():
    return render_template("center.html")


@bp.route('/guests')
def guests():
    guests_info = GuestModel.query.filter_by(merchant_id=g.user.id)
    return render_template("guests.html", data=guests_info)


@bp.route('/guests/history/<string:guest_name>')
def history(guest_name):
    purchase_history = OrderModel.query.filter_by(purchaser=guest_name, merchant_id=g.user.id)
    guest = GuestModel.query.filter_by(guest_name=guest_name, merchant_id=g.user.id).first()
    return render_template("history.html", data=purchase_history, guest=guest)

@bp.route('/export_csv', methods=['GET'])
def export_csv():
    data = OrderModel.query.filter_by(merchant_id=g.user.id).all()
    # 创建一个csv写入对象
    si = StringIO()
    cw = csv.writer(si)
    # 写入表头
    header = ['ID', 'GoodsName', 'Purchaser', 'Quantity', 'Price', 'Total', 'Paid', 'OrderTime', 'Contact']
    cw.writerow(header)
    # 写入数据
    print(data)
    for item in data:
        row = [item.order_id, item.goods_name, item.purchaser, item.quantity, item.price, item.total, item.paid,
               item.order_time, item.contact]
        cw.writerow(row)

    output = BytesIO()
    value = si.getvalue()
    output.write(value.encode('utf-8'))
    output.seek(0)

    response = send_file(output, as_attachment=True, download_name='orders.csv', mimetype='text/csv')
    return response


@bp.route('/export_xlsx', methods=['GET'])
def export_xlsx():
    orders = OrderModel.query.filter_by(merchant_id=g.user.id).all()
    order_dicts = [
        {'OrderID': order.order_id, 'GoodsName': order.goods_name, 'Purchaser': order.purchaser,
         'Quantity': order.quantity, 'Price': order.price, 'Total': order.total, 'Paid': order.paid,
         'OrderTime': order.order_time, 'Contact': order.contact}
        for order in orders
    ]
    df = pd.DataFrame(order_dicts)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name='orders.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@bp.route('/cartogram.png')
def cartogram():
    sales_data = OrderModel.query.filter_by(merchant_id=g.user.id).order_by(OrderModel.order_time).all()
    tz = pytz.timezone('Asia/Shanghai')
    daily_sales = OrderModel.query.with_entities(func.date(OrderModel.order_time).label('sale_date'),
                                                 func.sum(OrderModel.total).label('total_amount')).\
        filter_by(merchant_id=g.user.id).group_by('sale_date').order_by('sale_date').all()
    dates = []
    amount = []
    for sale in daily_sales:
        # 假设从数据库获取的是 UTC 时间，转换为本地时间
        utc_date = datetime.strptime(str(sale.sale_date), '%Y-%m-%d')
        # 转换为指定时区的时间（这里以 Asia/Shanghai 为例）
        local_date = utc_date.replace(tzinfo=pytz.timezone('UTC')).astimezone(tz)
        dates.append(local_date)
        amount.append(sale.total_amount)
    fig, ax = plt.subplots()
    ax.plot(dates, amount, marker='o', linestyle='-')
    locator = matplotlib.dates.DayLocator()
    ax.xaxis.set_major_locator(locator)
    data_format = DateFormatter('%m-%d')
    ax.xaxis.set_major_formatter(data_format)
    ax.set_xlabel('Sale Date')
    ax.set_ylabel('Sales Amount')
    ax.set_title('Sales Trend')
    for i, txt in enumerate(amount):
        ax.annotate(f"{txt:.2f}", (dates[i], amount[i]))
    plt.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    plt.close(fig)
    return send_file(buf, mimetype='image/png')

@bp.route('/display')
def display():
    return render_template("display.html")