from flask import Blueprint, render_template, request, redirect, url_for, flash, g
from .forms import GoodsForm, validate_goods
from models import OrderModel, GoodsModel
from exts import db

bp = Blueprint("goods", __name__, url_prefix="/goods")


@bp.route("/goods")
def create():
    return render_template("creategood.html")


@bp.route('/goods_create', methods=['GET', 'POST'])
def goods_create():
    if request.method == 'GET':
        return render_template("creategood.html")
    gd = GoodsForm(request.form)
    merchant_id = g.user.id
    goods_name = gd.goods_name.data
    storage_quantity = gd.storage_quantity.data
    cost_price = gd.cost_price.data
    goods_info = gd.goods_info.data
    message = validate_goods(goods_name, goods_info)
    if message:
        return redirect(url_for("goods.goods_create"))
    else:
        goods = GoodsModel(merchant_id=merchant_id, goods_name=goods_name, storage_quantity=storage_quantity, cost_price
        =cost_price, goods_info=goods_info)
        db.session.add(goods)
        db.session.commit()
        data = GoodsModel.query.filter_by(merchant_id=merchant_id)
        return render_template("goods.html", data=data)


@bp.route('/edit_goods/<int:info_id>', methods=['GET', 'POST'])
def edit_goods(info_id):
    if request.form == 'GET':
        return render_template("editgoods.html")
    else:
        new_gd = GoodsForm(request.form)
        merchant_id = g.user.id
        goods_name = new_gd.goods_name.data
        storage_quantity = new_gd.storage_quantity.data
        cost_price = new_gd.cost_price.data
        goods_info = new_gd.goods_info.data
        gd = GoodsModel.query.filter_by(goods_id=info_id).first()
        if goods_name:
            gd.goods_name = goods_name
            db.session.commit()
        if storage_quantity:
            gd.storage_quantity = storage_quantity
            db.session.commit()
        if cost_price:
            gd.cost_price = cost_price
            db.session.commit()
        if goods_info:
            gd.goods_info = goods_info
            db.session.commit()
        data = GoodsModel.query.filter_by(merchant_id=merchant_id)
        return render_template("goods.html", data=data)


@bp.route('/edit/<int:data_id>')
def edit(data_id):
    print(data_id)
    data = GoodsModel.query.filter_by(goods_id=data_id).first_or_404()
    return render_template("editgoods.html", data=data)

@bp.route('/delete_goods/<int:delete_id>')
def delete_goods(delete_id):
    merchant_id = g.user.id if g.user else None
    gd = GoodsModel.query.filter_by(goods_id=delete_id, merchant_id=merchant_id).first()
    if gd is None:
        return "错误"
    print(gd.goods_name)
    db.session.delete(gd)
    db.session.commit()
    data = GoodsModel.query.filter_by(merchant_id=merchant_id)
    return render_template("goods.html", data=data)


