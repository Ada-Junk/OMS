from flask import Blueprint, render_template, request, redirect, url_for, flash, g
from .forms import OrderForm, validate_create_order
from models import OrderModel, GuestModel, GoodsModel
from exts import db

bp = Blueprint("order", __name__, url_prefix="/order")


@bp.route("/create")
def create():
    return render_template("create.html")


@bp.route("/create_order", methods=['GET', 'POST'])
def create_order():
    order_form = OrderForm(request.form)
    merchant_id = g.user.id
    purchaser = order_form.purchaser.data
    goods_name = order_form.goods_name.data
    price = order_form.price.data
    quantity = order_form.quantity.data
    paid = order_form.paid.data
    contact = order_form.contact.data
    message = validate_create_order(quantity, price, contact, purchaser, goods_name)
    goods_storage = GoodsModel.query.filter_by(goods_name=goods_name, merchant_id=g.user.id).first()
    od_name = OrderModel.query.filter_by(purchaser=purchaser, merchant_id=g.user.id).all()
    guest_exit = GuestModel.query.filter_by(guest_name=purchaser, merchant_id=g.user.id).first()
    if message:
        flash(message)
        return render_template("create.html")
    elif goods_storage.storage_quantity < quantity:
        flash("订单数量不能多于库存数量")
        # order数量不能多于库存数量
        return render_template("create.html")
    else:
        order = OrderModel(merchant_id=merchant_id, purchaser=purchaser, goods_name=goods_name, quantity=quantity,
                           price=price, total=price * quantity,
                           paid=paid, contact=contact)
        # 修改库存数量
        total_quantity = goods_storage.storage_quantity
        goods_storage.storage_quantity = total_quantity - quantity
        db.session.commit()
        tl = 0
        # 查询当前客户是否存在
        if guest_exit and od_name:
            ods = OrderModel.query.filter_by(purchaser=purchaser, merchant_id=g.user.id)
            for od in ods:
                tl += od.total
            guest_exit.paid_total = tl
            db.session.commit()
        # 删除客户
        elif not od_name and guest_exit:
            guest = GuestModel.query.filter_by(merchant_id=g.user.id, guest_name=purchaser).first()
            db.session.delete(guest)
            db.session.commit()
            order_deleted = OrderModel.query.filter_by(merchant_id=g.user.id, purchaser=purchaser).all()
            db.session.delete(order_deleted)
            db.session.commit()
            return redirect(url_for("order.create_order"))
        else:
            guest = GuestModel(merchant_id=merchant_id, guest_name=purchaser, guest_contact=contact,
                               paid_total=price * quantity)
            db.session.add(guest)
            db.session.commit()
        db.session.add(order)
        db.session.commit()
        data = OrderModel.query.filter_by(merchant_id=merchant_id)
        return render_template('order.html', data=data)


@bp.route("/edit_order/<int:order_id>", methods=['GET', 'POST'])
def edit_order(order_id):
    if request.form == 'GET':
        return render_template("editorder.html")
    else:
        # 新输入的值
        new_od = OrderForm(request.form)
        merchant_id = g.user.id
        purchaser = new_od.purchaser.data
        goods_name = new_od.goods_name.data
        price = new_od.price.data
        quantity = new_od.quantity.data
        paid = new_od.paid.data
        contact = new_od.contact.data
        #找出旧order
        old_od = OrderModel.query.filter_by(order_id=order_id).first()
        #寻找是否有该商品
        gd1 = GoodsModel.query.filter_by(goods_name=goods_name, merchant_id=merchant_id).first()
        #寻找是否有该顾客
        pr = GuestModel.query.filter_by(guest_name=purchaser, merchant_id=merchant_id).first()
        if goods_name == old_od.goods_name or not goods_name:
            if quantity:
                gd2 = GoodsModel.query.filter_by(goods_name=old_od.goods_name, merchant_id=merchant_id).first()
                if (gd2.storage_quantity + old_od.quantity) < quantity:
                    flash("库存不足！")
                    return render_template("editorder.html", data=old_od)
                gd2.storage_quantity = gd2.storage_quantity + old_od.quantity - quantity
                old_od.quantity = quantity
                db.session.commit()
            if price:
                old_od.price = price
                db.session.commit()
            #新的单价与数量
            p = old_od.price
            q = old_od.quantity
            if purchaser == old_od.purchaser or not purchaser: #原来的顾客或者不输入,更新guest信息
                pt = GuestModel.query.filter_by(merchant_id=merchant_id, guest_name=old_od.purchaser).first()
                od = OrderModel.query.filter_by(merchant_id=merchant_id, purchaser=old_od.purchaser).all()
                print(od)
                t = 0
                for i in od:
                    print(i.total)
                    t += i.total
                del_money = old_od.total
                new_money = p * q
                pt.paid_total = t - del_money + new_money
                print(t, del_money, new_money, pt.paid_total)
                db.session.commit()
            elif purchaser and pr:#新输入顾客存在
                old_pr = OrderModel.query.filter_by(merchant_id=merchant_id, purchaser=old_od.purchaser).all()
                k = 0
                for i in old_pr:
                    k += 1
                if k == 1:  # 旧顾客只有一个订单
                    del_pr = GuestModel.query.filter_by(merchant_id=merchant_id, guest_name=old_od.purchaser).first()
                    db.session.delete(del_pr)
                    old_od.purchaser = purchaser
                    db.session.commit()
                    new_contact = OrderModel.query.filter_by(merchant_id=merchant_id, purchaser=purchaser).first().contact
                    old_od.contact = new_contact
                    pr.paid_total += p * q
                    db.session.commit()
                else:
                    old_od.purchaser = purchaser
                    del_pr = GuestModel.query.filter_by(merchant_id=merchant_id, guest_name=old_od.purchaser).first()
                    del_pr.paid_total -= old_od.total
                    old_od.contact = contact
                    pr.paid_total += p * q
                    old_pr.paid_total -= old_od.total
            elif purchaser and not pr:#新输入的顾客且不存在
                old_pr = OrderModel.query.filter_by(merchant_id=merchant_id, purchaser=old_od.purchaser).all()
                k = 0
                for i in old_pr:
                    k += 1
                if k == 1:#旧顾客只有一个订单
                    del_pr = GuestModel.query.filter_by(merchant_id=merchant_id, guest_name=old_od.purchaser).first()
                    db.session.delete(del_pr)
                    db.session.commit()
                    now_od = OrderModel.query.filter_by(merchant_id=merchant_id, order_id=order_id).first()
                    contact = now_od.contact
                    price = now_od.price
                    quantity = now_od.quantity
                    old_od.purchaser = purchaser
                    new_pr = GuestModel(merchant_id=merchant_id, guest_name=purchaser, guest_contact=contact,
                                        paid_total=price * quantity)
                    db.session.add(new_pr)
                    db.session.commit()
                else:#旧顾客有多个订单,改名减钱
                    gt = GuestModel.query.filter_by(merchant_id=merchant_id, guest_name=old_od.purchaser).first()
                    gt.paid_total -= old_od.total
                    now_od = OrderModel.query.filter_by(merchant_id=merchant_id, order_id=order_id).first()
                    contact = now_od.contact
                    price = now_od.price
                    quantity = now_od.quantity
                    old_od.purchaser = purchaser
                    new_pr = GuestModel(merchant_id=merchant_id, guest_name=purchaser, guest_contact=contact,
                                        paid_total=price * quantity)
                    db.session.add(new_pr)
                    db.session.commit()
                old_od.total = p * q
                db.session.commit()
            old_od.paid = paid
            db.session.commit()
        elif gd1 and gd1.goods_name != old_od.goods_name:
            gd2 = GoodsModel.query.filter_by(goods_name=old_od.goods_name, merchant_id=merchant_id).first()
            if quantity and quantity < gd1.storage_quantity:
                gd1.storage_quantity -= quantity
                gd2.storage_quantity += old_od.quantity
                old_od.quantity = quantity
                db.sessionss.commit()
            else:
                flash("购买数量超过库存！")
                return render_template("editorder.html", data=old_od)
            if price:
                old_od.price = gd1.cost_price
                db.session.commit()
            if contact:
                if not OrderModel.query.filter_by(contact=contact, merchant_id=merchant_id).first():
                    for item in OrderModel.query.filter_by(merchant_id=merchant_id, goods_name=goods_name).all():
                        item.contact = contact
                        db.session.commit()
            if purchaser:
                pr = GuestModel.query.filter_by(guest_name=purchaser, merchant_id=merchant_id).first()
                if pr:
                    old_od.purchaser = purchaser
                    db.session.commit()
                else:
                    now_od = OrderModel.query.filter_by(merchant_id=merchant_id).first()
                    contact = now_od.contact
                    price = now_od.price
                    quantity = now_od.quantity
                    old_od.purchaser = purchaser
                    new_pr = GuestModel(merchant_id=merchant_id, guest_name=purchaser, guest_contact=contact,
                                        paid_total=price * quantity)
                    db.session.add(new_pr)
                    db.session.commit()
            old_od.paid = paid
            db.session.commit()
        elif not gd1:
            flash("商品库存找不到此商品！")
            return render_template("editorder.html", data=old_od)
        data = OrderModel.query.filter_by(merchant_id=merchant_id)
        return render_template("order.html", data=data)


@bp.route("/edit/<int:od_id>")
def edit(od_id):
    data = OrderModel.query.filter_by(order_id=od_id).first()
    return render_template("editorder.html", data=data)
