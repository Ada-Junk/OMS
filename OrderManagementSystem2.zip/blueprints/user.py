from flask import Blueprint, render_template, request, redirect, url_for, session, flash, g
from .forms import RegisterForm, LoginForm, validate_register, UserNameForm, PasswordForm
from models import UserModel
from werkzeug.security import generate_password_hash, check_password_hash
from exts import db

bp = Blueprint("user", __name__, url_prefix="/user")

# /user/login
#GET：从服务器获取数据
#POST：将客户端的数据提交给服务器


@bp.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template("register.html")
    else:
        fm = RegisterForm(request.form)
        username = fm.username.data
        password = fm.password.data
        password_confirm = fm.password_confirm.data
        agreement = fm.agreement.data
        # print(agreement)
        # print(request)
        message = validate_register(username, password, password_confirm, agreement)
        if fm.validate():
            p = generate_password_hash(password)
            user = UserModel(username=username, password=p)
            db.session.add(user)
            db.session.commit()
            print(request.method)
            return redirect(url_for("user.login"))
        else:
            flash(message)
            print(fm.errors)
            return redirect(url_for("user.register"))

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("login.html")
    else:
        fm = LoginForm(request.form)
        if fm.validate():
            username = fm.username.data
            password = fm.password.data
            user = UserModel.query.filter_by(username=username).first()
            if not user:
                flash("用户名不存在！")
                return redirect(url_for("user.login"))
            if check_password_hash(user.password, password):
                # cookie 存储少量数据，存放登录授权信息
                # flask中的session，经过加密后存储在cookie
                session['user_id'] = user.id
                return redirect("/")
            else:
                flash("密码错误！")
                return redirect(url_for("user.login"))
        else:
            print(fm.errors)
            return redirect(url_for("user.login"))


@bp.route('/edit_username', methods=['GET', 'POST'])
def edit_username():
    if request.method == 'GET':
        return render_template("center.html")
    else:
        merchant_id = g.user.id
        nu = UserNameForm(request.form)
        new_username = nu.new_username.data
        if nu.validate():
            user = UserModel.query.filter_by(id=merchant_id).first()
            user.username = new_username
            db.session.commit()
            return redirect(url_for("user.login"))
        else:
            flash("该用户名已存在！")
            return render_template("center.html")


@bp.route('/edit_password', methods=['GET', 'POST'])
def edit_password():
    if request.method == 'GET':
        return render_template("center.html")
    else:
        merchant_id = g.user.id
        np = PasswordForm(request.form)
        if np.validate():
            password = np.password.data
            new_password = np.new_password.data
            new_password_confirm = np.new_password_confirm.data
            user = UserModel.query.filter_by(id=merchant_id).first()
            print(password, new_password, new_password_confirm, user.id)
            if not check_password_hash(g.user.password, password):
                flash("旧密码输入错误！")
                return render_template("center.html")
            else:
                p = generate_password_hash(new_password)
                user.password = p
                db.session.commit()
                return redirect(url_for("user.login"))
        else:
            flash("新密码不一致或格式错误！")
            return render_template("center.html")

