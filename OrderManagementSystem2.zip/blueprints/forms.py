from wtforms import Form, StringField, BooleanField
from wtforms.validators import Length, EqualTo, DataRequired, NumberRange
from models import UserModel, OrderModel
import wtforms


from flask import g


# Form 用来验证前段的数据是否符合
class RegisterForm(wtforms.Form):
    username = wtforms.StringField(validators=[Length(min=4, max=15, message="用户名格式错误！")])
    password = wtforms.StringField(validators=[Length(min=6, max=15, message="密码格式错误！")])
    password_confirm = wtforms.StringField(validators=[EqualTo("password", message="两次密码不一致！")])
    agreement = wtforms.BooleanField()

    def validate_username(self, field):
        username = field.data
        un = UserModel.query.filter_by(username=username).first()
        if un:
            raise wtforms.ValidationError(message="该用户名已被注册！")

    def validate_agreement(self, field):
        agreement = field.data
        if not agreement:
            raise wtforms.ValidationError(message="请同意服务条款！")


def validate_register(username, password, password_confirm, agreement):
    # username = field.data
    # password = field.data
    # password_confirm = field.data
    # agreement = field.data
    print(agreement)
    un = UserModel.query.filter_by(username=username).first()
    if un:
        return "该用户名已存在！"
    else:
        if len(username) < 4:
            return "用户名长度至少4个字符！"
        elif len(username) > 15:
            return "用户名长度不多于15个字符！"
        elif password != password_confirm:
            return "两次密码不一致！"
        elif len(password) < 6:
            return "密码长度至少6个字符！"
        elif len(password) > 15:
            return "密码长度不多于15个字符！"
        elif not agreement:
            return "请同意服务条款！"
        else:
            pass


class LoginForm(wtforms.Form):
    username = wtforms.StringField(validators=[Length(min=4, max=20, message="用户名错误！")])
    password = wtforms.StringField(validators=[Length(min=3, max=20, message="密码错误！")])


class OrderForm(wtforms.Form):
    purchaser = wtforms.StringField()
    goods_name = wtforms.StringField()
    quantity = wtforms.IntegerField()
    price = wtforms.FloatField()
    contact = wtforms.StringField()
    paid = wtforms.BooleanField()


def validate_create_order(quantity, price, contact, purchaser, goods_name):
    if not purchaser:
        return "购买人不能为空！"
    elif not goods_name:
        return "商品名不能为空！"
    elif quantity <= 0:
        return "购买数量不能小于1！"
    elif price <= 0:
        return "商品单价不能小于等于0！"
    elif len(contact) != 11:
        return "联系方式错误！"
    return None


class GoodsForm(wtforms.Form):
    goods_id = wtforms.StringField()
    goods_name = wtforms.StringField()
    storage_quantity = wtforms.IntegerField(NumberRange(min=0, message="库存数量不能小于0！"))
    cost_price = wtforms.FloatField()
    goods_info = wtforms.StringField()


def validate_goods(goods_name, goods_info):
    if not goods_name:
        return "商品名称不能为空！"
    # elif storage_quantity <= 0:
    #     return "库存数量不能低于0！"
    # elif cost_price <= 0:
    #     return "成本价不能等于0！"
    elif not goods_info:
        return "商品信息不能为空！"


class GuestForm(wtforms.Form):
    guest_id = wtforms.StringField()
    guest_name = wtforms.StringField()
    storage_quantity = wtforms.IntegerField()
    cost_price = wtforms.FloatField()
    goods_info = wtforms.StringField()


def validate_guest(guest_name, storage_quantity, cost_price, goods_info):
    if not guest_name:
        pass


class UserNameForm(wtforms.Form):
    new_username = wtforms.StringField(validators=[DataRequired(message="用户名不能为空！")])
    def validate_new_username(self, field):
        new_username = field.data
        if not new_username:
            return wtforms.ValidationError(message="用户名不能为空！")
        user = UserModel.query.filter_by(username=new_username).first()
        if user:
            raise wtforms.ValidationError(message="该用户名已被注册！")
class PasswordForm(wtforms.Form):
    password = wtforms.StringField(validators=[Length(min=6, max=15, message="密码格式错误！")])
    new_password = wtforms.StringField(validators=[Length(min=6, max=15, message="密码格式错误！")])
    new_password_confirm = wtforms.StringField(validators=[EqualTo("new_password", message="两次密码不一致！")])
