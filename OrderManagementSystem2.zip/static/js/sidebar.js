const btn = document.querySelector("#btn");
const sidebar = document.querySelector(".lsidebar");
btn.addEventListener("click",() => {
    sidebar.classList.toggle("active");
})