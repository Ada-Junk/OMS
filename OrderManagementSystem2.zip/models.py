from exts import db
from datetime import datetime
from sqlalchemy import ForeignKey
from flask import g
class UserModel(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    register_time = db.Column(db.DateTime, default=datetime.now())
    orders = db.relationship("OrderModel", backref="merchant", lazy='dynamic', cascade="all, delete-orphan")
    goods = db.relationship("GoodsModel", backref="merchant", lazy='dynamic', cascade="all, delete-orphan")
    guests = db.relationship("GuestModel", backref="merchant", lazy='dynamic', cascade="all, delete-orphan")

class OrderModel(db.Model):
    __tablename__ = "order"
    order_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    merchant_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    purchaser = db.Column(db.String(20), nullable=False)
    goods_name = db.Column(db.String(200), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    total = db.Column(db.Integer, nullable=False)
    contact = db.Column(db.String(20), nullable=False)
    paid = db.Column(db.Boolean, default=False)
    order_time = db.Column(db.DateTime, default=datetime.now())


class GoodsModel(db.Model):
    __tablename__ = "goods"
    goods_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    merchant_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    goods_name = db.Column(db.String(200), nullable=True)
    storage_quantity = db.Column(db.Integer, nullable=True)
    cost_price = db.Column(db.Float, nullable=True)
    goods_info = db.Column(db.String(200), nullable=True)

class GuestModel(db.Model):
    __tablename__ = "guest"
    guest_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    merchant_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    guest_name = db.Column(db.String(20), nullable=False)
    guest_contact = db.Column(db.String(20), nullable=False)
    paid_total = db.Column(db.Float, nullable=False)